﻿namespace DishesAPI.Models
{
    public class DishForUpdateDto
    {
        public required string Name { get; set; }
    }
}
